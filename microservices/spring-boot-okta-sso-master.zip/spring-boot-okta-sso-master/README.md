# spring-boot-okta-sso
How to Add Single Sign-On to Your Spring Boot Web Application using okta &amp; OAuth 2.0
