# spring-cloud-loadbalance-eureka
How to balance load using spring cloud ribbon and eureka
