# spring-cloud-consul
how to centralize configuration using spring cloud consul

Download consul :  https://www.consul.io/downloads.html

Commands:
-------------------------

Check IP : ipconfig


bootstrap consul : consul agent -server -bootstrap-expect=1 -data-dir=consul-data -ui -bind=YOUR_IP_ADDRESS
