# pcf-service-registry
How to use service registry in pivotal cloud foundry to register your microservice 
