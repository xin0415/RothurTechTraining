# cloud-consul-service-discovery
How to use cloud consul as service discovery 
