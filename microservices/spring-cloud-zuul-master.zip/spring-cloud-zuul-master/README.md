# spring-cloud-zuul
How to configure SpringCloud Zuul – Routing and Filtering | SpringBoot
