# spring-cloud-sleuth-zipkin-example
 how to use Sleuth to add tracing information in logs. In addition to that, we can also export this information to Zipkin so that we can visualize this through UI
