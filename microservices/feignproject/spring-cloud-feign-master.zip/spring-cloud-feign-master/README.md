# spring-cloud-fegin
How to consume external service using feign client
