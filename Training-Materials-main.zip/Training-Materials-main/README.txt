On Boarding
1. Training Content
	first 3 weeks:
		Java core (4)
		Database (1 - 2)
		Hibernate/Spring Core, MVC, Boot
		Micro service, Spring Cloud
	starting from 4th week:
		Mock interview (Evaluation -> layoff)
		Resume (top candidates -> advanced marketing)
		How to prepare your project
		Kafka/ AWS / docker / testing / CICD / Agile ...

2. Training Time
	Tuesday 7:30PM EST - 9:30PM EST
	Thursday 7:30PM EST - 9:30PM EST
	Saturday 1:30PM EST - 3:30PM EST

3. Evaluation
	4th week evaluation.
	homework
	attendance (on time, ask leave allow)

4. Layoff Policy
	didn't do homework, 
	didn't attend class on time
	didn't pass 4th week evaluation
	first time warning -> drop


5. Tracking Sheet
	https://docs.google.com/spreadsheets/d/1GIy-uaCRC9jYPEpP6nA4X8aIIwag8DB9vp11BtJMl0U/edit#gid=0

6. Update name in Slack
	FirstName_LastName_01_09_2023

7. Marketing
	mock interview
	interview support
	most recent interview question list

8. English
















	



	



	