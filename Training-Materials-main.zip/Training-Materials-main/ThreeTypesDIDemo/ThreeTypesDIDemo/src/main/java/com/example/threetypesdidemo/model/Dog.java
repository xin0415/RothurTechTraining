package com.example.threetypesdidemo.model;

public class Dog {
    String name;
    Integer age;
}
