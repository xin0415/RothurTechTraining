package com.example.threetypesdidemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThreeTypesDiDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
