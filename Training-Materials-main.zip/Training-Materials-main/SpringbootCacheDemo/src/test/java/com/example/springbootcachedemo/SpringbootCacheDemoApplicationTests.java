package com.example.springbootcachedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCacheDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
