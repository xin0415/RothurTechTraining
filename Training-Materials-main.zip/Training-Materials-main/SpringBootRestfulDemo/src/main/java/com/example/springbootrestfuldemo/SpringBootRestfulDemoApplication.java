package com.example.springbootrestfuldemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestfulDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootRestfulDemoApplication.class, args);
    }

}
