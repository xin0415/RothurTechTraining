package com.example.springbootrestfuldemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestfulDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
